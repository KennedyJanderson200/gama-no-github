Tutorial básico criado para a comunidade Hiring Coders tratando o consumo de uma API usando JS Vanilla.
[Video](https://youtu.be/69SGdDf6Aws).